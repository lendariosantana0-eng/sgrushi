# BackendLand (demo)

Backend simples em Node.js/Express com MongoDB para testes de mod.

## Endpoints
- `GET /config.json` -> retorna config.
- `POST /user/login/` -> body JSON: `{ deviceId, country, hash }` - retorna JSON do usuário.
- `POST /admin/ban` -> body JSON: `{ username, action }` onde `action` é `ban` ou `unban`.
- `GET /admin/users` -> lista users (apenas debug).

## Instalação
```bash
git clone <repo>
cd backendland
npm install
npm start
```

## Configuração MongoDB

1. Crie um arquivo `.env` na raiz do projeto
2. Configure a variável `MONGODB_URI` com sua connection string:

```env
MONGODB_URI=mongodb://default:SUA_SENHA_AQUI@square-cloud-db-6fbf928d0f534d9a9c53a5527261e174.squareweb.app:7125
```

Substitua `SUA_SENHA_AQUI` pela senha real do seu banco MongoDB.

## Variáveis de ambiente
- `MONGODB_URI` (obrigatório) - Connection string do MongoDB
- `PORT` (opcional, padrão: 3000)
- `SERVER_HASH` (opcional) - Hash para autenticação

## Migração de dados

Na primeira execução, o sistema automaticamente migra dados existentes do `db.json` para o MongoDB. Após a migração, o arquivo `db.json` não é mais necessário.

## Observações
- Este backend é **para desenvolvimento/testes**. Não use em produção sem ajustes de segurança (autenticação, TLS, autorização).
- Dados são persistidos no MongoDB configurado.
