// server.js
require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const mongoose = require('mongoose');
const { nanoid } = require('nanoid');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://default:YOUR_PASSWORD_HERE@square-cloud-db-6fbf928d0f534d9a9c53a5527261e174.squareweb.app:7125';

const app = express();
app.use(cors());
app.use(bodyParser.json());

// MongoDB connection
async function connectMongoDB() {
  try {
    await mongoose.connect(MONGODB_URI);
    console.log('[Backend] Connected to MongoDB');
  } catch (error) {
    console.error('[Backend] MongoDB connection error:', error);
    process.exit(1);
  }
}

// Mongoose schemas
const userSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true },
  deviceId: { type: String, required: true, unique: true },
  country: { type: String, default: 'BR' },
  username: { type: String, required: true },
  crowns: { type: Number, default: 0 },
  gems: { type: Number, default: 0 },
  trophys: { type: Number, default: 0 }, // NOTE: keeping the typo as per original
  skillRating: { type: Number, default: 0 },
  balances: [{
    name: { type: String, required: true },
    amount: { type: Number, default: 0 }
  }],
  banned: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now }
});

const configSchema = new mongoose.Schema({
  name: { type: String, default: 'BackendLand' },
  version: { type: String, default: '1.0.0' },
  message: { type: String, default: 'Backend de teste para mod' },
  maintenance: { type: Boolean, default: false }
}, { collection: 'config' });

const banSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true }
});

// Models
const User = mongoose.model('User', userSchema);
const Config = mongoose.model('Config', configSchema);
const Ban = mongoose.model('Ban', banSchema);

async function migrateData() {
  try {
    // Check if migration already happened
    const existingUsers = await User.countDocuments();
    if (existingUsers > 0) {
      console.log('[Backend] Data already migrated');
      return;
    }

    // Read existing data from db.json
    const DB_FILE = path.join(__dirname, 'db.json');
    if (!fs.existsSync(DB_FILE)) {
      console.log('[Backend] No db.json file found, skipping migration');
      return;
    }

    const data = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
    console.log('[Backend] Migrating data from db.json to MongoDB...');

    // Migrate config
    if (data.config) {
      const config = new Config(data.config);
      await config.save();
      console.log('[Backend] Config migrated');
    }

    // Migrate users
    if (data.users && Array.isArray(data.users)) {
      for (const userData of data.users) {
        const user = new User(userData);
        await user.save();
      }
      console.log(`[Backend] ${data.users.length} users migrated`);
    }

    // Migrate bans
    if (data.bans && Array.isArray(data.bans)) {
      for (const username of data.bans) {
        const ban = new Ban({ username });
        await ban.save();
      }
      console.log(`[Backend] ${data.bans.length} bans migrated`);
    }

    console.log('[Backend] Data migration completed');
  } catch (error) {
    console.error('[Backend] Error during data migration:', error);
  }
}

async function initDb() {
  try {
    // Run migration first
    await migrateData();

    // Ensure config document exists (fallback)
    let config = await Config.findOne();
    if (!config) {
      config = new Config({
        name: "BackendLand",
        version: "1.0.0",
        message: "Backend de teste para mod",
        maintenance: false
      });
      await config.save();
      console.log('[Backend] Default config created');
    }
  } catch (error) {
    console.error('[Backend] Error initializing database:', error);
  }
}

// Utilitários
async function findUserByDevice(deviceId) {
  try {
    return await User.findOne({ deviceId });
  } catch (error) {
    console.error('[Backend] Error finding user by device:', error);
    return null;
  }
}

async function isBanned(username) {
  if (!username) return false;
  try {
    const ban = await Ban.findOne({ username: new RegExp(`^${username}$`, 'i') });
    return !!ban;
  } catch (error) {
    console.error('[Backend] Error checking ban status:', error);
    return false;
  }
}

// Endpoints

// Config estático (GET /config.json)
app.get('/config.json', async (req, res) => {
  try {
    const config = await Config.findOne();
    res.json(config || {
      name: "BackendLand",
      version: "1.0.0",
      message: "Backend de teste para mod",
      maintenance: false
    });
  } catch (error) {
    console.error('[Backend] Error getting config:', error);
    res.status(500).json({ error: 'internal_error' });
  }
});

// Endpoint de login que o mod espera (POST /user/login/)
app.post('/user/login/', async (req, res) => {
  try {
    const { deviceId, country, hash } = req.body || {};

    // validações básicas
    if (!deviceId) {
      return res.status(400).json({ error: 'deviceId required' });
    }

    // ---------- Autenticação simples ----------
    const acceptedHash = process.env.SERVER_HASH || 'VinAW5ATPxIZS3fe9OEqirN35SyOil4zMTgiHFAOfKkkamiTV0EqKjXibc9ZydTHAsSVBMWww71bnGieEDfB1jBT3xf9JnWZAr9W5cvDj2IUtBk0yOUEh0nMGsLiF8G7';

    // Busca usuário por deviceId
    let user = await findUserByDevice(deviceId);

    if (!user) {
      // cria novo usuário default
      user = new User({
        id: nanoid(),
        deviceId,
        country: country || 'BR',
        username: `Player_${deviceId.slice(0,6)}`,
        crowns: 0,
        gems: 0,
        // NOTE: mod espera "trophys" (erro de ortografia comum) — manter chave
        trophys: 0,
        skillRating: 0,
        balances: [
          { name: 'gems', amount: 0 },
          { name: 'coins', amount: 0 }
        ],
        banned: false
      });
      await user.save();
      console.log(`[Backend] Novo usuário criado: ${user.username} (${user.deviceId})`);
    }

    // checagem de ban local
    if (await isBanned(user.username) || user.banned) {
      console.log(`[Backend] Login rejeitado: usuário banido => ${user.username}`);
      return res.json({
        authorized: false,
        banned: true,
        message: 'User is banned',
        username: user.username
      });
    }

    // forma de retorno compatível com o mod
    const responsePayload = {
      authorized: hash === acceptedHash,
      banned: false,
      username: user.username,
      crowns: user.crowns,
      gems: user.gems,
      coins: user.balances.find(b => b.name === 'coins')?.amount || 0,
      trophys: user.trophys,
      skillRating: user.skillRating,
      balances: user.balances,
      message: hash === acceptedHash ? 'Authorized' : 'UnauthorizedHash'
    };

    console.log(`[Backend] Login request: device=${deviceId}, username=${user.username}, authorized=${responsePayload.authorized}`);
    return res.json(responsePayload);
  } catch (err) {
    console.error('[Backend] Erro em /user/login/:', err);
    return res.status(500).json({ error: 'internal_error' });
  }
});

// Endpoint admin para ban (POST /admin/ban) - simples e inseguro, só pra dev/test
// body: { username: "nome", action: "ban" | "unban" }
app.post('/admin/ban', async (req, res) => {
  try {
    const { username, action } = req.body || {};
    if (!username || !action) return res.status(400).json({ error: 'username and action required' });

    if (action === 'ban') {
      // Add to bans collection if not already there
      const existingBan = await Ban.findOne({ username: new RegExp(`^${username}$`, 'i') });
      if (!existingBan) {
        const ban = new Ban({ username });
        await ban.save();
      }

      // Update user banned status
      await User.findOneAndUpdate(
        { username: new RegExp(`^${username}$`, 'i') },
        { banned: true }
      );

      console.log(`[Backend] Usuario banido: ${username}`);
      return res.json({ ok: true, banned: true });
    } else if (action === 'unban') {
      // Remove from bans collection
      await Ban.deleteMany({ username: new RegExp(`^${username}$`, 'i') });

      // Update user banned status
      await User.findOneAndUpdate(
        { username: new RegExp(`^${username}$`, 'i') },
        { banned: false }
      );

      console.log(`[Backend] Usuario desbanido: ${username}`);
      return res.json({ ok: true, banned: false });
    } else {
      return res.status(400).json({ error: 'unknown action' });
    }
  } catch (err) {
    console.error('[Backend] Erro em /admin/ban:', err);
    return res.status(500).json({ error: 'internal_error' });
  }
});

// Endpoint para ver users (GET /admin/users) - só pra debug
app.get('/admin/users', async (req, res) => {
  try {
    const users = await User.find({});
    res.json(users);
  } catch (error) {
    console.error('[Backend] Error getting users:', error);
    res.status(500).json({ error: 'internal_error' });
  }
});

app.listen(PORT, async () => {
  await connectMongoDB();
  await initDb();
  console.log(`[Backend] BackendLand iniciado na porta ${PORT}`);
  console.log(`[Backend] GET /config.json  POST /user/login/  POST /admin/ban`);
});
